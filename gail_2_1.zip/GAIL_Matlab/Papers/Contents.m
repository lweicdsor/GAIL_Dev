% PAPERS
%
% Folders
%   ConesNotBallsPaper  - code of examples in Cones Not Balls Paper  
%   MCQMC2012Paper      - code of examples in MCQMC paper
%   meanMCBerPaper      - code of examples in meanMCBer paper
%   Paper_cubLattice_g  - code of examples in cubLattice_g paper
%   Paper_cubSobol_g    - code of examples in cubSobol_g paper
%   UniFunMin           - code of examples in Xin Tong's thesis  
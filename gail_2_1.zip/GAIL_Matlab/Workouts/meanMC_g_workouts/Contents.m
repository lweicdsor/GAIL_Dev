% MEANMC_G_WORKOUTS
%
% Files
%   Test_meanMC_g - the driver file to test meanMC_g algorithm
%   Ytrafficmodel - the Nagel-Schreckenberg traffic model 
%   dt_meanMC_g_TrafficModel - test traffic model

% CUBMC_G_WORKOUTS
%
% Files
%   genz_test_fun      - A suite of test functions from Alan Genz and Keister
%   genz_test_fun_true - Calculate true integrals of seven test functions
%   Test_cubMC_g       - Driver script to test the cubMC_g algorithm
%   dt_cubMC_g         - Lengthy doc tests for cubMC_g
%   cubMCTestFun.pdf   - The description of the seven test functions used in Test_cubMC_g

% univariate_minimization_workouts
% 
%
% Files
%
% workout_ErrToleranceTest.m --- test for Bump test functions with specific
% number of iteration, absolut error tolerance and cost budget nmax
%
% workout_XToleranceTest.m --- test for Bump test functions with specific 
% number of iteration, X tolerance and cost budget nmax
%
% workout_ErrXToleranceTest.m --- test for Bump test functions with a 
% specific number of iteration, absolut error tolerance, X tolerance and
% cost budget nmax
%  
% workout_TwoExtremeTest.m --- test for Functions with two local minimum 
% points with specific number of iteration, X tolerance, and cost budget 
% nmax





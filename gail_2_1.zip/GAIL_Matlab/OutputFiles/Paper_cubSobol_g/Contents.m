% PAPER_CUBSOBOL_G
%
% Files
%
%  Paper_cubSobol_g_256ScrambledShiftedSobolPoints-2015-03-07-17-21-15.eps - figure 1 in paper
% 
%  Paper_cubSobol_g_256SobolPoints-2015-03-07-17-21-14.eps - figure 1 in paper
% 
%  Paper_cubSobol_g_FunctionWalshFourierCoeffDecay-2015-03-07-17-21-20.eps - function figure 2 in paper
% 
%  Paper_cubSobol_g_TestGeoAsianCall-2015-03-07-17-21-04.eps - figure 3 in paper
% 
%  Paper_cubSobol_g_TestGeoAsianCall-2015-03-07-17-21-06.mat - data used to plot
% 
%  Paper_cubSobol_g_TestKeister-2015-03-07-17-20-12.eps - another example similar to figure 3
% 
%  Paper_cubSobol_g_TestKeister-2015-03-07-17-20-13.mat - data used to plot
% 
%  Paper_cubSobol_g_WalshFourierCoeffDecay-2015-03-07-17-21-36.eps - figure 2 in paper

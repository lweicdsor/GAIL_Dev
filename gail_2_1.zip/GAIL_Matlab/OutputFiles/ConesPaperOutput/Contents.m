% CONESPAPEROUTPUT
%
% Files
%   ConesPaperFunAppxTest-03-Sep-2013-18-37-05 - dataset of function
%   approximation in Cones paper
%   ConesPaperFunAppxTest-2015-Jan-24-13-34-24 - reproduced dataset of
%   function approximation in Cones paper
%   ConePaperIntegralTest-2015-02-05-16-57-04 - dataset of integral in
%   Cones paper
%   ConesPaperFlukyquad - figure 1b) in Cones paper
%   ConesPaperSpikyquad - figure 1a) in Cones Paper


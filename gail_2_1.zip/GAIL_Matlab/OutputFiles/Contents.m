% OUTPUTFILES
%
% Folders
%   ConesPaperOutput      - output files of cones paper
%   MCQMC2012PaperOutput  - output files of MCQMC2012 paper
%   meanMCBerPaperOutput  - output files of meanMCBer paper
%   Paper_cubLattice_g    - output files of cubLattice paper
%   Paper_cubSobol_g      - output files of cubSobol paper
%   UniFunMinOutput       - output files of Xin Tong's thesis
%   WorkoutFunappxOutput  - output files of funappx_g workouts
%   WorkoutFunminOutput   - output files of funmin_g workouts
%   WorkoutIntegralOutput - output files of integral_g workouts

% meanMCBerPaperOutput

% abs-2015-03-01-23-56-31.eps --- figure 1 in paper

% plotHoeffCLTr-2015-03-01-23-55-41.eps---figure 2 in paper

% TestmeanMCBernoulli-on-abs-06-Sep-2014_03.18.10.mat---the MAT file used to plot
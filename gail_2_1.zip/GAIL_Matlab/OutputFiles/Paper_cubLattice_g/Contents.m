% PAPER_CUBLATTICE_G
%
%
% Files
%
%   Paper_cubLattice_g_TestKeister-2015-03-07-17-17-37.mat - data used to plot
% 
%   Paper_cubLattice_g_TestKeister-2015-03-07-17-17-36.eps - another example similar to figure 3
% 
%   Paper_cubLattice_g_TestGeoAsianCall-2015-03-07-17-16-16.mat - data used to plot
%  
%   Paper_cubLattice_g_TestGeoAsianCall-2015-03-07-17-16-15.eps - figure 3 in paper
% 
%   Paper_cubLattice_g_NodeSetExample-2015-03-07-17-05-57.eps - figure 1 in paper
% 
%   Paper_cubLattice_g_DualSetExample-2015-03-07-17-05-58.eps - figure 1 in paper
%
%   Paper_cubLattice_g_FourierCoeffDecay-2015-03-09-20-38-36. eps - figure 2 in paper
%
%   Paper_cubLattice_g_FunctionFourierCoeffDecay-2015-03-09-20-38-33.eps - function of figure 2 in paper

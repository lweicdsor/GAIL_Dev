% CONESPAPEROUTPUT
%
% Files
%   ConePaperIntegralTest-2015-02-15-16-57-04 - dataset of integral in
%   Cones paper

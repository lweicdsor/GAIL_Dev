% meanMCBerPaperOutput

% abs-2015-03-01-23-56-31.eps --- figure 1 in paper

% plotHoeffCLTr-2015-03-01-23-55-41.eps---figure 2 in paper

% TestmeanMCBer-on-abs--2015-03-04-13-51-44.mat---the MAT file used to plot
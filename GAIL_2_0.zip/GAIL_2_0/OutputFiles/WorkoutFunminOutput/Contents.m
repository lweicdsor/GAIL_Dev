% WorkoutFunminOutput
% 
%
% Files
%
% workout_ErrToleranceTest-2015-03-06-01-59-47.mat --- dataset of test for 
% Bump test functions with specific number of iteration, absolut error 
% tolerance and cost budget nmax
%
% workout_XToleranceTest-2015-03-06-04-21-37.mat --- dataset of test for
% Bump test functions with specific number of iteration, X tolerance and 
% cost budget nmax
%
% workout_ErrXToleranceTest-2015-03-06-05-05-09.mat --- dataset of test for
% Bump test functions with a specific number of iteration, absolut error 
% tolerance, X tolerance and cost budget nmax
%  
% workout_TwoExtremeTest-2015-03-06-08-55-15.mat --- dataset of test for 
% Functions with two local minimum points with specific number of 
% iteration, X tolerance, and cost budget nmax


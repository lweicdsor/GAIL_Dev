% MEANMCBERPAPER
%
% Files
%   PlotmeanMCBernoulli_gResults - This function is to generate the figure 1 in paper 
%   PlotRatioHoeffCLT            - This function is to generate the figure 2 in paper 
%   Test_meanMCBer_g             - This function is to test meanMCBer_g algorithm
%   JiangHickernellMCQMC2014.pdf - This is the paper for the algorithm
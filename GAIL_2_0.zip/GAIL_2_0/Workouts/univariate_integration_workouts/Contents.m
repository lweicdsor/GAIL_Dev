% UNIVARIATE_INTEGRATION_WORKOUTS
%
% Files
%
%   workout_integral_g    - Calls automatic guaranteed algorithm for
%   univariate integration
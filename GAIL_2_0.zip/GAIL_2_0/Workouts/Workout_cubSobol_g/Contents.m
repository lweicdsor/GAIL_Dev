% WORKOUTS_CUBSOBOL_G
% 
% Files 
%   test_cubSobol       - driver script to test cubSobol_g algorithm using integrands of dimensions up to 3 
%   test_cubSobol_ver_b - driver script to test cubSobol_g algorithm using integrands of various dimensions

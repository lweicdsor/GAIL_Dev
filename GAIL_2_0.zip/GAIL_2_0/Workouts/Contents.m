% WORKOUTS
%
% Folders
%
%   cubMC_workouts                    - workouts of cubMC_g method
%   meanMC_workouts                   - workouts of meanMC_g method
%   univariate_approximation_workouts - workouts of funappx_g method
%   univariate_integration_workouts   - workouts of integral_g method
%   univariate_minimization_workouts  - workouts of funmin_g method
%   Workout_cubSobol_g                - workouts of cubSobol_g

% UNIVARIATE_APPROXIMATION_WORKOUTS
%
% Files
%
%   workout_funappx_g --- comparison between funappx_g and funappxlocal_g
%   funappx_convtest --- time cost and computational cost comparison
%   between funappx_g and funappxlocal_g